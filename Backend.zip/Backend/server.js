require("dotenv").config();
const cors = require('cors')
const express = require("express");
const morgan = require("morgan");
const db = require("./db") //Automatically Looks for Index.js


const app = express();

// app.use(morgan("dev"));

// //Middleware
// app.use((req,res, next) => {
//     console.log("Yay our Middleware Ran")
//     next()
// });

app.use(cors())

app.use(express.json())

//Get all Categories
app.get("/api/v1/categories", async (req,res) => {
    try {
        const results = await db.query("SELECT * FROM categories"); //Query Database
        //onsole.log(results);
        res.status(200).json({
            status: "success",
            results: results.rows.length,
            data: {
                categories: results.rows,
            },
            
        });
    } catch (err) {
        console.log(err)
    }
    
});

//Get all Forums
app.get("/api/v1/forums", async (req,res) => {
    try {
        const results = await db.query("SELECT * FROM forums"); //Query Database
        //onsole.log(results);
        res.status(200).json({
            status: "success",
            results: results.rows.length,
            data: {
                forums: results.rows,
            },
            
        });
    } catch (err) {
        console.log(err)
    }
    
});

//Get all threads of all forums
app.get("/api/v1/topics", async (req,res) => {
    try {
        const results = await db.query("SELECT * FROM topics"); //Query Database
        //onsole.log(results);
        res.status(200).json({
            status: "success",
            results: results.rows.length,
            data: {
                topics: results.rows,
            },
            
        });
    } catch (err) {
        console.log(err)
    }
    
});

//Get all Posts
app.get("/api/v1/posts", async (req,res) => {
    try {
        const results = await db.query("SELECT * FROM posts"); //Query Database
        //onsole.log(results);
        res.status(200).json({
            status: "success",
            results: results.rows.length,
            data: {
                posts: results.rows,
            },
            
        });
    } catch (err) {
        console.log(err)
    }
    
});

//Get a Username from PrivyDID
app.get("/api/v1/users", async (req,res) => {
    try {
        const results = await db.query('SELECT username FROM users WHERE user_id = $1', [userId]); //Query Database
        //onsole.log(results);
        res.status(200).json({
            status: "success",
            results: results.rows.length,
            data: {
                users: results.rows,
            },
            
        });
    } catch (err) {
        console.log(err)
    }
    
});


//Create a New Thread
app.post("/api/v1/topics", async (req,res) => {
    console.log(req.body);
    
    try {
        const results = await db.query("INSERT INTO topics (forum_id, user_id, title) VALUES ($1,$2,$3) returning *", [req.body.forum_id, req.body.user_id, req.body.title]);
        console.log(results)
        res.status(201).json({
            status: "Success",
            data: {
                topics: results.rows[0]
            }
        })
    } catch (err) {
        console.log(err)
    }
    
});

//Create a New User
app.post("/api/v1/users", async (req,res) => {
    console.log(req.body);
    
    try {
        const results = await db.query("INSERT INTO users (user_id) VALUES ($1) returning *", [req.body.user_id]);
        console.log(results)
        res.status(201).json({
            status: "Success",
            data: {
                users: results.rows[0]
            }
        })
    } catch (err) {
        console.log(err)
    }
    
});

//Create a New Post
app.post("/api/v1/posts", async (req,res) => {
    console.log(req.body);
    
    try {
        const results = await db.query("INSERT INTO posts (topic_id, user_id, content) VALUES ($1,$2,$3) returning *", [req.body.topic_id, req.body.user_id, req.body.content]);
        console.log(results)
        res.status(201).json({
            status: "Success",
            data: {
                posts: results.rows[0]
            }
        })
    } catch (err) {
        console.log(err)
    }
    
});

//Get the Count of Number of Threads in Forum Category
app.get("/api/v1/operations/count-threads", async (req,res) => {
    try {
        const result = await db.query(
          "SELECT COUNT(*) AS count FROM topics WHERE forum_id = $1",
          [req.query.forum_id]
        );
    
        if (result.rows.length === 0) {
          return res.status(404).json(0); // No results found
        }
    
        const count = parseInt(result.rows[0].count, 10);
        res.status(200).json(count);
    
      } catch (err) {
        console.error(err);
        res.status(500).json(-1); // Server error
      }
    });

// Get the Count of Number of Posts in a Forum Category
app.get("/api/v1/operations/count-forum-posts", async (req, res) => {
    try {
      console.log("Received request with topic_id:", req.query.topic_id);
      
      if (!req.query.topic_id) {
        return res.status(400).json({ error: "topic_id is required" });
      }
  
      const result = await db.query(
        "SELECT COUNT(*) AS count FROM posts WHERE topic_id = $1",
        [req.query.topic_id]
      );
      
      console.log("Query result:", result.rows);
  
      if (result.rows.length === 0) {
        return res.status(404).json(0); // No results found
      }
  
      const count = parseInt(result.rows[0].count, 10);
      console.log("Sending count:", count);
      res.status(200).json(count);
    } catch (err) {
      console.error("Error in count-forum-posts:", err);
      res.status(500).json({ error: "Server error", details: err.message });
    }
  });

  // Route to update views count
app.get("/api/v1/operations/increment-views", async (req, res) => {
    try {
      console.log("Received request with topic_id:", req.query.topic_id);
      
      if (!req.query.topic_id) {
        return res.status(400).json({ error: "topic_id is required" });
      }
  
      const result = await db.query(
        "UPDATE topics SET views = views + 1 WHERE topic_id = $1 RETURNING views",
        [req.query.topic_id]
      );
      
      console.log("Query result:", result.rows);
  
      if (result.rows.length === 0) {
        return res.status(404).json(0); // No results found
      }
  
      const count = parseInt(result.rows[0].count, 10);
      console.log("Incrementing # of Views:", result.rows[0]);
      res.status(200).json(result.rows[0]);
    } catch (err) {
      console.error("Error in Incrementing Views:", err);
      res.status(500).json({ error: "Server error", details: err.message });
    }
  });

    // Route to get view count of thread
app.get("/api/v1/operations/get-views", async (req, res) => {
    try {
      console.log("Received request with topic_id:", req.query.topic_id);
      
      if (!req.query.topic_id) {
        return res.status(400).json({ error: "topic_id is required" });
      }
  
      const result = await db.query(
        "SELECT views FROM topics WHERE topic_id = $1",
        [req.query.topic_id]
      );
      
      console.log("Query result:", result.rows);
  
      if (result.rows.length === 0) {
        return res.status(404).json(0); // No results found
      }
  
      const count = parseInt(result.rows[0].count, 10);
      console.log("Sending # of Views:", result.rows[0]);
      res.status(200).json(result.rows[0]);
    } catch (err) {
      console.error("Error in Sending # of Views:", err);
      res.status(500).json({ error: "Server error", details: err.message });
    }
  });




// //Get a Indiviual Resturant
// app.get("/api/v1/resturants/:id", async (req,res) => {
//     console.log(req.params.id)

//     try {
//         const resturant = await db.query("SELECT * FROM resturants WHERE id = $1", [req.params.id]) //Paramterized Query to Avoid SQL Injection. Dont use String Interpolation.
//         console.log(resturant.rows)


//         const reviews = await db.query("SELECT * FROM reviews WHERE resturant_id = $1", [req.params.id]) //Paramterized Query to Avoid SQL Injection. Dont use String Interpolation.
//         console.log(reviews.rows)

//         res.status(200).json({
//             status: "Success",
//             data: {
//                 resturant: resturant.rows[0],
//                 reviews: reviews.rows
//             },
//         })
//     } catch (err) {
//         console.log(err)
//     }
    
// });

// //Create a Resturant
// app.post("/api/v1/resturants", async (req,res) => {
//     console.log(req.body);

//     try {
//         const results = await db.query("INSERT INTO resturants (name, location, price_range) VALUES ($1,$2,$3) returning *", [req.body.name, req.body.location, req.body.price_range]);
//         console.log(results)
//         res.status(201).json({
//             status: "Success",
//             data: {
//                 resturant: results.rows[0]
//             }
//         })
//     } catch (err) {
//         console.log(err)
//     }
    
// });

// // Update Resturants
// app.put("/api/v1/resturants/:id", async (req, res) => {
    
//     try {
//         const results = await db.query('UPDATE resturants SET name = $1 , location = $2 , price_range = $3 WHERE id = $4 returning *', [req.body.name, req.body.location, req.body.price_range, req.params.id]);
//         console.log(results)
//         console.log("Client Wants to Update Id:",req.params.id),
//         console.log(req.body)
//         res.status(200).json({
//         status: "Success",
//         data: {
//             resturant: results.rows[0]
//         }
//     })
//     } catch (err) {
//         console.log(err);
//     }

    
// });

// //Delete Resturant
// app.delete("/api/v1/resturants/:id", async (req, res) => {
//     try {
//         const results = await db.query("DELETE FROM resturants WHERE id = $1", [req.params.id]);
//         res.status(204).json({
//             status: "success",
//         })
//         console.log("Delete Response Hit")
//     } catch (err) {
//         console.log(err)
//     }
    
// })

// //Add Review
// app.post("/api/v1/resturants/:id/addReview", async (req,res) => {
// try {
//     const newReview = await db.query("INSERT INTO reviews (resturant_id, name, review, rating) values ($1,$2,$3,$4) returning *", [req.params.id, req.body.name, req.body.review, req.body.rating]);
//     res.status(201).json({
//         status: 'success',
//         data: {
//             review: newReview.rows[0]
//         }
//     })
// } catch (err) {
//     console.log(err)
// }
// })

const port = process.env.PORT || 3005;

app.listen(port, () => {
    console.log(`Aquari Server is up and listening on port ${port}`);
});